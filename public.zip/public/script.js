
const addButton = document.getElementById('addButton');
const taskInput = document.getElementById('taskInput');
const todoList = document.getElementById('todoList');


function loadTodos() {
    fetch('http://localhost:3000/todos')
        .then(response => response.json())
        .then(todos => {
            todoList.innerHTML = '';
            todos.forEach(todo => {
                const li = document.createElement('li');
                li.textContent = todo.task;

                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'O\'chirish';
                deleteButton.onclick = () => deleteTodo(todo.id);

                li.appendChild(deleteButton);
                todoList.appendChild(li);
            });
        })
        .catch(error => console.error('Error loading todos:', error));
}


addButton.addEventListener('click', () => {
    const task = taskInput.value;
    if (task) {
        fetch('http://localhost:3000/todos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ task })
        })
        .then(response => response.json())
        .then(() => {
            taskInput.value = '';
            loadTodos();
        })
        .catch(error => console.error('Error adding todo:', error));
}});

function deleteTodo(id) {
    fetch(`http://localhost:3000/todos/${id}`, {
        method: 'DELETE'
    })
    .then(() => loadTodos())
    .catch(error => console.error('Error deleting todo:', error));
}

loadTodos();
